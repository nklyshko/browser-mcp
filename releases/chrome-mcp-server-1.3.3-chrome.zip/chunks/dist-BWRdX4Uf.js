//#region ../../packages/shared/dist/index.mjs
var NativeMessageType = /* @__PURE__ */ ((NativeMessageType2) => {
	NativeMessageType2["START"] = "start";
	NativeMessageType2["STARTED"] = "started";
	NativeMessageType2["STOP"] = "stop";
	NativeMessageType2["STOPPED"] = "stopped";
	NativeMessageType2["PING"] = "ping";
	NativeMessageType2["PONG"] = "pong";
	NativeMessageType2["ERROR"] = "error";
	NativeMessageType2["PROCESS_DATA"] = "process_data";
	NativeMessageType2["PROCESS_DATA_RESPONSE"] = "process_data_response";
	NativeMessageType2["CALL_TOOL"] = "call_tool";
	NativeMessageType2["CALL_TOOL_RESPONSE"] = "call_tool_response";
	NativeMessageType2["CANCEL_TOOL"] = "cancel_tool";
	NativeMessageType2["SERVER_STARTED"] = "server_started";
	NativeMessageType2["SERVER_STOPPED"] = "server_stopped";
	NativeMessageType2["ERROR_FROM_NATIVE_HOST"] = "error_from_native_host";
	NativeMessageType2["CONNECT_NATIVE"] = "connectNative";
	NativeMessageType2["ENSURE_NATIVE"] = "ensure_native";
	NativeMessageType2["PING_NATIVE"] = "ping_native";
	NativeMessageType2["DISCONNECT_NATIVE"] = "disconnect_native";
	return NativeMessageType2;
})(NativeMessageType || {});
var TOOL_NAMES = {
	BROWSER: {
		GET_WINDOWS_AND_TABS: "get_windows_and_tabs",
		SEARCH_TABS_CONTENT: "search_tabs_content",
		NAVIGATE: "chrome_navigate",
		SCREENSHOT: "chrome_screenshot",
		CLOSE_TABS: "chrome_close_tabs",
		SWITCH_TAB: "chrome_switch_tab",
		WEB_FETCHER: "chrome_get_web_content",
		CLICK: "chrome_click_element",
		FILL: "chrome_fill_or_select",
		REQUEST_ELEMENT_SELECTION: "chrome_request_element_selection",
		GET_INTERACTIVE_ELEMENTS: "chrome_get_interactive_elements",
		NETWORK_CAPTURE: "chrome_network_capture",
		BLOCK_IMAGES: "chrome_block_images",
		NETWORK_CAPTURE_START: "chrome_network_capture_start",
		NETWORK_CAPTURE_STOP: "chrome_network_capture_stop",
		NETWORK_REQUEST: "chrome_network_request",
		NETWORK_DEBUGGER_START: "chrome_network_debugger_start",
		NETWORK_DEBUGGER_STOP: "chrome_network_debugger_stop",
		KEYBOARD: "chrome_keyboard",
		HISTORY: "chrome_history",
		BOOKMARK_SEARCH: "chrome_bookmark_search",
		BOOKMARK_ADD: "chrome_bookmark_add",
		BOOKMARK_DELETE: "chrome_bookmark_delete",
		INJECT_SCRIPT: "chrome_inject_script",
		SEND_COMMAND_TO_INJECT_SCRIPT: "chrome_send_command_to_inject_script",
		JAVASCRIPT: "chrome_javascript",
		CONSOLE: "chrome_console",
		FILE_UPLOAD: "chrome_upload_file",
		READ_PAGE: "chrome_read_page",
		COMPUTER: "chrome_computer",
		HANDLE_DIALOG: "chrome_handle_dialog",
		HANDLE_DOWNLOAD: "chrome_handle_download",
		USERSCRIPT: "chrome_userscript",
		PERFORMANCE_START_TRACE: "performance_start_trace",
		PERFORMANCE_STOP_TRACE: "performance_stop_trace",
		PERFORMANCE_ANALYZE_INSIGHT: "performance_analyze_insight",
		GIF_RECORDER: "chrome_gif_recorder",
		GET_TAB_URL: "chrome_get_tab_url",
		GET_SCROLL_STATE: "chrome_get_scroll_state",
		SCROLL: "chrome_scroll",
		WAIT: "chrome_wait",
		EXTRACT: "chrome_extract",
		GET_PAGE_TEXT: "chrome_get_page_text",
		CLICK_AND_WAIT: "chrome_click_and_wait"
	},
	RECORD_REPLAY: {
		FLOW_RUN: "record_replay_flow_run",
		LIST_PUBLISHED: "record_replay_list_published"
	}
};
var TOOL_SCHEMAS = [
	{
		name: TOOL_NAMES.BROWSER.GET_WINDOWS_AND_TABS,
		description: "Get all currently open browser windows and tabs",
		inputSchema: {
			type: "object",
			properties: {},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.PERFORMANCE_START_TRACE,
		description: "Starts a performance trace recording on the selected page. Optionally reloads the page and/or auto-stops after a short duration.",
		inputSchema: {
			type: "object",
			properties: {
				reload: {
					type: "boolean",
					description: "Determines if, once tracing has started, the page should be automatically reloaded (ignore cache)."
				},
				autoStop: {
					type: "boolean",
					description: "Determines if the trace should be automatically stopped (default false)."
				},
				durationMs: {
					type: "number",
					description: "Auto-stop duration in milliseconds when autoStop is true (default 5000)."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.PERFORMANCE_STOP_TRACE,
		description: "Stops the active performance trace recording on the selected page.",
		inputSchema: {
			type: "object",
			properties: {
				saveToDownloads: {
					type: "boolean",
					description: "Whether to save the trace as a JSON file in Downloads (default true)."
				},
				filenamePrefix: {
					type: "string",
					description: "Optional filename prefix for the downloaded trace JSON."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.PERFORMANCE_ANALYZE_INSIGHT,
		description: "Provides a lightweight summary of the last recorded trace. For deep insights (CWV, breakdowns), integrate native-side DevTools trace engine.",
		inputSchema: {
			type: "object",
			properties: {
				insightName: {
					type: "string",
					description: "Optional insight name for future deep analysis (e.g., \"DocumentLatency\"). Currently informational only."
				},
				timeoutMs: {
					type: "number",
					description: "Timeout for deep analysis via native host (milliseconds). Default 60000. Increase for large traces."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.READ_PAGE,
		description: `Get an accessibility tree representation of visible elements on the page. Only returns elements that are visible in the viewport. Optionally filter for only interactive elements.
Tip: If the returned elements do not include the specific element you need, use the computer tool's screenshot (action="screenshot") to capture the element's on-screen coordinates, then operate by coordinates.`,
		inputSchema: {
			type: "object",
			properties: {
				filter: {
					type: "string",
					description: "Filter elements: \"interactive\" for such as  buttons/links/inputs only (default: all visible elements)"
				},
				depth: {
					type: "number",
					description: "Maximum DOM depth to traverse (integer >= 0). Lower values reduce output size and can improve performance."
				},
				refId: {
					type: "string",
					description: "Focus on the subtree rooted at this element refId (e.g., \"ref_12\"). The refId must come from a recent chrome_read_page response in the same tab (refs may expire)."
				},
				tabId: {
					type: "number",
					description: "Target an existing tab by ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab when tabId is omitted."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.COMPUTER,
		description: "Use a mouse and keyboard to interact with a web browser, and take screenshots.\n* Whenever you intend to click on an element like an icon, you should consult a read_page to determine the ref of the element before moving the cursor.\n* If you tried clicking on a program or link but it failed to load, even after waiting, try screenshot and then adjusting your click location so that the tip of the cursor visually falls on the element that you want to click.\n* Make sure to click any buttons, links, icons, etc with the cursor tip in the center of the element. Don't click boxes on their edges unless asked.",
		inputSchema: {
			type: "object",
			properties: {
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)"
				},
				background: {
					type: "boolean",
					description: "Avoid focusing/activating tab/window for certain operations (best-effort). Default: true; set false only when foreground interaction is required."
				},
				action: {
					type: "string",
					description: "Action to perform: left_click | right_click | double_click | triple_click | left_click_drag | scroll | scroll_to | type | key | fill | fill_form | hover | wait | resize_page | zoom | screenshot"
				},
				ref: {
					type: "string",
					description: "Element ref from chrome_read_page. For click/scroll/scroll_to/key/type and drag end when provided; takes precedence over coordinates."
				},
				coordinates: {
					type: "object",
					properties: {
						x: {
							type: "number",
							description: "X coordinate"
						},
						y: {
							type: "number",
							description: "Y coordinate"
						}
					},
					description: "Coordinates for actions (in screenshot space if a recent screenshot was taken, otherwise viewport). Required for click/scroll and as end point for drag."
				},
				startCoordinates: {
					type: "object",
					properties: {
						x: { type: "number" },
						y: { type: "number" }
					},
					description: "Starting coordinates for drag action"
				},
				startRef: {
					type: "string",
					description: "Drag start ref from chrome_read_page (alternative to startCoordinates)."
				},
				scrollDirection: {
					type: "string",
					description: "Scroll direction: up | down | left | right"
				},
				scrollAmount: {
					type: "number",
					description: "Scroll ticks (1-10), default 3"
				},
				text: {
					type: "string",
					description: "Text to type (for action=type) or keys/chords separated by space (for action=key, e.g. \"Backspace Enter\" or \"cmd+a\")"
				},
				repeat: {
					type: "number",
					description: "For action=key: number of times to repeat the key sequence (integer 1-100, default 1)."
				},
				modifiers: {
					type: "object",
					description: "Modifier keys for click actions (left_click/right_click/double_click/triple_click).",
					properties: {
						altKey: { type: "boolean" },
						ctrlKey: { type: "boolean" },
						metaKey: { type: "boolean" },
						shiftKey: { type: "boolean" }
					}
				},
				region: {
					type: "object",
					description: "For action=zoom: rectangular region to capture (x0,y0)-(x1,y1) in viewport pixels (or screenshot-space if a recent screenshot context exists).",
					properties: {
						x0: { type: "number" },
						y0: { type: "number" },
						x1: { type: "number" },
						y1: { type: "number" }
					},
					required: [
						"x0",
						"y0",
						"x1",
						"y1"
					]
				},
				selector: {
					type: "string",
					description: "CSS selector for fill (alternative to ref)."
				},
				value: {
					oneOf: [
						{ type: "string" },
						{ type: "boolean" },
						{ type: "number" }
					],
					description: "Value to set for action=fill (string | boolean | number)"
				},
				elements: {
					type: "array",
					description: "For action=fill_form: list of elements to fill (ref + value)",
					items: {
						type: "object",
						properties: {
							ref: {
								type: "string",
								description: "Element ref from chrome_read_page"
							},
							value: {
								type: "string",
								description: "Value to set (stringified if non-string)"
							}
						},
						required: ["ref", "value"]
					}
				},
				width: {
					type: "number",
					description: "For action=resize_page: viewport width"
				},
				height: {
					type: "number",
					description: "For action=resize_page: viewport height"
				},
				appear: {
					type: "boolean",
					description: "For action=wait with text: whether to wait for the text to appear (true, default) or disappear (false)"
				},
				timeout: {
					type: "number",
					description: "For action=wait with text: timeout in milliseconds (default 10000, max 120000)"
				},
				duration: {
					type: "number",
					description: "Seconds to wait for action=wait (max 30s)"
				}
			},
			required: ["action"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.NAVIGATE,
		description: "Navigate to a URL, refresh the current tab, or navigate browser history (back/forward)",
		inputSchema: {
			type: "object",
			properties: {
				url: {
					type: "string",
					description: "URL to navigate to. Special values: \"back\" or \"forward\" to navigate browser history in the target tab."
				},
				newWindow: {
					type: "boolean",
					description: "Create a new window to navigate to the URL or not. Defaults to false"
				},
				tabId: {
					type: "number",
					description: "Target an existing tab by ID (if provided, navigate/refresh/back/forward that tab instead of the active tab)."
				},
				windowId: {
					type: "number",
					description: "Target an existing window by ID (when creating a new tab in existing window, or picking active tab if tabId is not provided)."
				},
				background: {
					type: "boolean",
					description: "Perform the operation without stealing focus (do not activate the tab or focus the window). Default: true; set false only when foreground interaction is required."
				},
				width: {
					type: "number",
					description: "Window width in pixels (default: 1280). When width or height is provided, a new window will be created."
				},
				height: {
					type: "number",
					description: "Window height in pixels (default: 720). When width or height is provided, a new window will be created."
				},
				refresh: {
					type: "boolean",
					description: "Refresh the current active tab instead of navigating to a URL. When true, the url parameter is ignored. Defaults to false"
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.SCREENSHOT,
		description: "[Prefer read_page over taking a screenshot and Prefer chrome_computer] Take a screenshot of the current page or a specific element. For new usage, use chrome_computer with action=\"screenshot\". Use this tool if you need advanced options.",
		inputSchema: {
			type: "object",
			properties: {
				name: {
					type: "string",
					description: "Name for the screenshot, if saving as PNG"
				},
				selector: {
					type: "string",
					description: "CSS selector for element to screenshot"
				},
				tabId: {
					type: "number",
					description: "Target tab ID to capture from (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from when tabId is not provided."
				},
				background: {
					type: "boolean",
					description: "Attempt capture without bringing tab/window to foreground. CDP-based capture is used for simple viewport captures. For element/full-page capture, the tab may still be made active in its window without focusing the window. Default: false"
				},
				width: {
					type: "number",
					description: "Width in pixels (default: 800)"
				},
				height: {
					type: "number",
					description: "Height in pixels (default: 600)"
				},
				storeBase64: {
					type: "boolean",
					description: "return screenshot in base64 format (default: false) if you want to see the page, recommend set this to be true"
				},
				fullPage: {
					type: "boolean",
					description: "Store screenshot of the entire page (default: true)"
				},
				savePng: {
					type: "boolean",
					description: "Save screenshot as PNG file (default: true)，if you want to see the page, recommend set this to be false, and set storeBase64 to be true"
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.CLOSE_TABS,
		description: "Close one or more browser tabs",
		inputSchema: {
			type: "object",
			properties: {
				tabIds: {
					type: "array",
					items: { type: "number" },
					description: "Array of tab IDs to close. If not provided, will close the active tab."
				},
				url: {
					type: "string",
					description: "Close tabs matching this URL. Can be used instead of tabIds."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.SWITCH_TAB,
		description: "Switch to a specific browser tab",
		inputSchema: {
			type: "object",
			properties: {
				tabId: {
					type: "number",
					description: "The ID of the tab to switch to."
				},
				windowId: {
					type: "number",
					description: "The ID of the window where the tab is located."
				}
			},
			required: ["tabId"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.WEB_FETCHER,
		description: "Fetch content from a web page",
		inputSchema: {
			type: "object",
			properties: {
				url: {
					type: "string",
					description: "URL to fetch content from. If not provided, uses the current active tab"
				},
				tabId: {
					type: "number",
					description: "Target an existing tab by ID (default: active tab)."
				},
				background: {
					type: "boolean",
					description: "Do not activate tab/focus window while fetching (default: true)"
				},
				htmlContent: {
					type: "boolean",
					description: "Get the visible HTML content of the page. If true, textContent will be ignored (default: false)"
				},
				textContent: {
					type: "boolean",
					description: "Get the visible text content of the page with metadata. Ignored if htmlContent is true (default: true)"
				},
				selector: {
					type: "string",
					description: "CSS selector to get content from a specific element. If provided, only content from this element will be returned"
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.NETWORK_REQUEST,
		description: "Send a network request from the browser with cookies and other browser context",
		inputSchema: {
			type: "object",
			properties: {
				url: {
					type: "string",
					description: "URL to send the request to"
				},
				method: {
					type: "string",
					description: "HTTP method to use (default: GET)"
				},
				headers: {
					type: "object",
					description: "Headers to include in the request"
				},
				body: {
					type: "string",
					description: "Body of the request (for POST, PUT, etc.)"
				},
				timeout: {
					type: "number",
					description: "Timeout in milliseconds (default: 30000)"
				},
				formData: {
					type: "object",
					description: "Multipart/form-data descriptor. If provided, overrides body and builds FormData with optional file attachments. Shape: { fields?: Record<string,string|number|boolean>, files?: Array<{ name: string, fileUrl?: string, filePath?: string, base64Data?: string, filename?: string, contentType?: string }> }. Also supports a compact array form: [ [name, fileSpec, filename?], ... ] where fileSpec may be url:, file:, or base64:."
				}
			},
			required: ["url"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.NETWORK_CAPTURE,
		description: "Unified network capture tool. Use action=\"start\" to begin capturing, action=\"stop\" to end and retrieve results. Set needResponseBody=true to capture response bodies (uses Debugger API, may conflict with DevTools). Default mode uses webRequest API (lightweight, no debugger conflict, but no response body).",
		inputSchema: {
			type: "object",
			properties: {
				action: {
					type: "string",
					enum: ["start", "stop"],
					description: "Action to perform: \"start\" begins capture, \"stop\" ends and returns results"
				},
				needResponseBody: {
					type: "boolean",
					description: "When true, captures response body using Debugger API (default: false). Only use when you need to inspect response content."
				},
				url: {
					type: "string",
					description: "URL to capture network requests from. For action=\"start\". If not provided, uses the current active tab."
				},
				maxCaptureTime: {
					type: "number",
					description: "Maximum capture time in milliseconds (default: 180000)"
				},
				inactivityTimeout: {
					type: "number",
					description: "Stop after inactivity in milliseconds (default: 60000). Set 0 to disable."
				},
				includeStatic: {
					type: "boolean",
					description: "Include static resources like images/scripts/styles (default: false)"
				}
			},
			required: ["action"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.BLOCK_IMAGES,
		description: "Block image network requests in a tab using Chrome DevTools Protocol. Start this before navigating or reloading to prevent future image downloads; stop restores normal image loading.",
		inputSchema: {
			type: "object",
			properties: {
				action: {
					type: "string",
					enum: ["start", "stop"],
					description: "\"start\" blocks future image requests; \"stop\" restores image loading"
				},
				tabId: {
					type: "number",
					description: "Target tab ID. Defaults to the active tab."
				}
			},
			required: ["action"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.HANDLE_DOWNLOAD,
		description: "Wait for a browser download and return details (id, filename, url, state, size)",
		inputSchema: {
			type: "object",
			properties: {
				filenameContains: {
					type: "string",
					description: "Filter by substring in filename or URL"
				},
				timeoutMs: {
					type: "number",
					description: "Timeout in ms (default 60000, max 300000)"
				},
				waitForComplete: {
					type: "boolean",
					description: "Wait until completed (default true)"
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.HISTORY,
		description: "Retrieve and search browsing history from Chrome",
		inputSchema: {
			type: "object",
			properties: {
				text: {
					type: "string",
					description: "Text to search for in history URLs and titles. Leave empty to retrieve all history entries within the time range."
				},
				startTime: {
					type: "string",
					description: "Start time as a date string. Supports ISO format (e.g., \"2023-10-01\", \"2023-10-01T14:30:00\"), relative times (e.g., \"1 day ago\", \"2 weeks ago\", \"3 months ago\", \"1 year ago\"), and special keywords (\"now\", \"today\", \"yesterday\"). Default: 24 hours ago"
				},
				endTime: {
					type: "string",
					description: "End time as a date string. Supports ISO format (e.g., \"2023-10-31\", \"2023-10-31T14:30:00\"), relative times (e.g., \"1 day ago\", \"2 weeks ago\", \"3 months ago\", \"1 year ago\"), and special keywords (\"now\", \"today\", \"yesterday\"). Default: current time"
				},
				maxResults: {
					type: "number",
					description: "Maximum number of history entries to return. Use this to limit results for performance or to focus on the most relevant entries. (default: 100)"
				},
				excludeCurrentTabs: {
					type: "boolean",
					description: "When set to true, filters out URLs that are currently open in any browser tab. Useful for finding pages you've visited but don't have open anymore. (default: false)"
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.BOOKMARK_SEARCH,
		description: "Search Chrome bookmarks by title and URL",
		inputSchema: {
			type: "object",
			properties: {
				query: {
					type: "string",
					description: "Search query to match against bookmark titles and URLs. Leave empty to retrieve all bookmarks."
				},
				maxResults: {
					type: "number",
					description: "Maximum number of bookmarks to return (default: 50)"
				},
				folderPath: {
					type: "string",
					description: "Optional folder path or ID to limit search to a specific bookmark folder. Can be a path string (e.g., \"Work/Projects\") or a folder ID."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.BOOKMARK_ADD,
		description: "Add a new bookmark to Chrome",
		inputSchema: {
			type: "object",
			properties: {
				url: {
					type: "string",
					description: "URL to bookmark. If not provided, uses the current active tab URL."
				},
				title: {
					type: "string",
					description: "Title for the bookmark. If not provided, uses the page title from the URL."
				},
				parentId: {
					type: "string",
					description: "Parent folder path or ID to add the bookmark to. Can be a path string (e.g., \"Work/Projects\") or a folder ID. If not provided, adds to the \"Bookmarks Bar\" folder."
				},
				createFolder: {
					type: "boolean",
					description: "Whether to create the parent folder if it does not exist (default: false)"
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.BOOKMARK_DELETE,
		description: "Delete a bookmark from Chrome",
		inputSchema: {
			type: "object",
			properties: {
				bookmarkId: {
					type: "string",
					description: "ID of the bookmark to delete. Either bookmarkId or url must be provided."
				},
				url: {
					type: "string",
					description: "URL of the bookmark to delete. Used if bookmarkId is not provided."
				},
				title: {
					type: "string",
					description: "Title of the bookmark to help with matching when deleting by URL."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.JAVASCRIPT,
		description: "Execute JavaScript code in a browser tab and return the result. Uses CDP Runtime.evaluate with awaitPromise and returnByValue; automatically falls back to chrome.scripting.executeScript if the debugger is busy. Output is sanitized (sensitive data redacted) and truncated by default.",
		inputSchema: {
			type: "object",
			properties: {
				code: {
					type: "string",
					description: "JavaScript code to execute. Runs inside an async function body, so top-level await and \"return ...\" are supported."
				},
				tabId: {
					type: "number",
					description: "Target tab ID. If omitted, uses the current active tab."
				},
				timeoutMs: {
					type: "number",
					description: "Execution timeout in milliseconds (default: 15000)."
				},
				maxOutputBytes: {
					type: "number",
					description: "Maximum output size in bytes after sanitization (default: 51200). Output exceeding this limit will be truncated."
				},
				requireResult: {
					type: "boolean",
					description: "Require the script to return a value. When true, a script that completes with undefined returns a no_result error; default false keeps action-only scripts successful."
				}
			},
			required: ["code"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.CLICK,
		description: "Click on an element in a web page. Supports multiple targeting methods: CSS selector, XPath, element ref (from chrome_read_page), or viewport coordinates. More focused than chrome_computer for simple click operations.",
		inputSchema: {
			type: "object",
			properties: {
				selector: {
					type: "string",
					description: "CSS selector or XPath for the element to click."
				},
				selectorType: {
					type: "string",
					enum: ["css", "xpath"],
					description: "Type of selector (default: \"css\")."
				},
				ref: {
					type: "string",
					description: "Element ref from chrome_read_page (takes precedence over selector)."
				},
				coordinates: {
					type: "object",
					description: "Viewport coordinates to click at.",
					properties: {
						x: { type: "number" },
						y: { type: "number" }
					},
					required: ["x", "y"]
				},
				double: {
					type: "boolean",
					description: "Perform double click when true (default: false)."
				},
				button: {
					type: "string",
					enum: [
						"left",
						"right",
						"middle"
					],
					description: "Mouse button to click (default: \"left\")."
				},
				modifiers: {
					type: "object",
					description: "Modifier keys to hold during click.",
					properties: {
						altKey: { type: "boolean" },
						ctrlKey: { type: "boolean" },
						metaKey: { type: "boolean" },
						shiftKey: { type: "boolean" }
					}
				},
				waitForNavigation: {
					type: "boolean",
					description: "Wait for navigation to complete after click (default: false)."
				},
				timeout: {
					type: "number",
					description: "Timeout in milliseconds for waiting (default: 5000)."
				},
				tabId: {
					type: "number",
					description: "Target tab ID. If omitted, uses the current active tab."
				},
				windowId: {
					type: "number",
					description: "Window ID to select active tab from (when tabId is omitted)."
				},
				frameId: {
					type: "number",
					description: "Target frame ID for iframe support."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.FILL,
		description: "Fill or select a form element on a web page. Supports input, textarea, select, checkbox, and radio elements. Use CSS selector, XPath, or element ref to target the element.",
		inputSchema: {
			type: "object",
			properties: {
				selector: {
					type: "string",
					description: "CSS selector or XPath for the form element."
				},
				selectorType: {
					type: "string",
					enum: ["css", "xpath"],
					description: "Type of selector (default: \"css\")."
				},
				ref: {
					type: "string",
					description: "Element ref from chrome_read_page (takes precedence over selector)."
				},
				value: {
					type: [
						"string",
						"number",
						"boolean"
					],
					description: "Value to fill. For text inputs: string. For checkboxes/radios: boolean. For selects: option value or text."
				},
				tabId: {
					type: "number",
					description: "Target tab ID. If omitted, uses the current active tab."
				},
				windowId: {
					type: "number",
					description: "Window ID to select active tab from (when tabId is omitted)."
				},
				frameId: {
					type: "number",
					description: "Target frame ID for iframe support."
				}
			},
			required: ["value"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.REQUEST_ELEMENT_SELECTION,
		description: "Request the user to manually select one or more elements on the current page. Use this as a human-in-the-loop fallback when you cannot reliably locate the target element after approximately 3 attempts using chrome_read_page combined with chrome_click_element/chrome_fill_or_select/chrome_computer. The user will see a panel with instructions and can click on the requested elements. Returns element refs compatible with chrome_click_element/chrome_fill_or_select (including iframe frameId for cross-frame support).",
		inputSchema: {
			type: "object",
			properties: {
				requests: {
					type: "array",
					description: "A list of element selection requests. Each request produces exactly one picked element. The user will see these requests in a panel and select each element by clicking on the page.",
					minItems: 1,
					items: {
						type: "object",
						properties: {
							id: {
								type: "string",
								description: "Optional stable request id for correlation. If omitted, an id is auto-generated (e.g., \"req_1\")."
							},
							name: {
								type: "string",
								description: "Short label shown to the user describing what element to select (e.g., \"Login button\", \"Email input field\")."
							},
							description: {
								type: "string",
								description: "Optional longer instruction shown to the user with more context (e.g., \"Click on the primary login button in the top-right corner\")."
							}
						},
						required: ["name"]
					}
				},
				timeoutMs: {
					type: "number",
					description: "Timeout in milliseconds for the user to complete all selections. Default: 180000 (3 minutes). Maximum: 600000 (10 minutes)."
				},
				tabId: {
					type: "number",
					description: "Target tab ID. If omitted, uses the current active tab."
				},
				windowId: {
					type: "number",
					description: "Window ID to select active tab from (when tabId is omitted)."
				}
			},
			required: ["requests"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.KEYBOARD,
		description: "Simulate keyboard input on a web page. Supports single keys (Enter, Tab, Escape), key combinations (Ctrl+C, Ctrl+V), and text input. Can target a specific element or send to the focused element.",
		inputSchema: {
			type: "object",
			properties: {
				keys: {
					type: "string",
					description: "Keys or key combinations to simulate. Examples: \"Enter\", \"Tab\", \"Ctrl+C\", \"Shift+Tab\", \"Hello World\"."
				},
				selector: {
					type: "string",
					description: "CSS selector or XPath for target element to receive keyboard events."
				},
				selectorType: {
					type: "string",
					enum: ["css", "xpath"],
					description: "Type of selector (default: \"css\")."
				},
				delay: {
					type: "number",
					description: "Delay between keystrokes in milliseconds (default: 50)."
				},
				tabId: {
					type: "number",
					description: "Target tab ID. If omitted, uses the current active tab."
				},
				windowId: {
					type: "number",
					description: "Window ID to select active tab from (when tabId is omitted)."
				},
				frameId: {
					type: "number",
					description: "Target frame ID for iframe support."
				}
			},
			required: ["keys"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.CONSOLE,
		description: "Capture console output from a browser tab. Supports snapshot mode (default; one-time capture with ~2s wait) and buffer mode (persistent per-tab buffer you can read/clear instantly without waiting).",
		inputSchema: {
			type: "object",
			properties: {
				url: {
					type: "string",
					description: "URL to navigate to and capture console from. If not provided, uses the current active tab"
				},
				tabId: {
					type: "number",
					description: "Target an existing tab by ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab when tabId is omitted."
				},
				background: {
					type: "boolean",
					description: "Do not activate tab/focus window when capturing via CDP. Default: true"
				},
				includeExceptions: {
					type: "boolean",
					description: "Include uncaught exceptions in the output (default: true)"
				},
				maxMessages: {
					type: "number",
					description: "Maximum number of console messages to capture in snapshot mode (default: 100). If limit is provided, it takes precedence."
				},
				mode: {
					type: "string",
					enum: ["snapshot", "buffer"],
					description: "Console capture mode: snapshot (default; waits ~2s for messages) or buffer (persistent per-tab buffer; reads from memory instantly)."
				},
				buffer: {
					type: "boolean",
					description: "Alias for mode=\"buffer\" (default: false)."
				},
				clear: {
					type: "boolean",
					description: "Buffer mode only: clear the buffered logs for this tab before reading (default: false). Use clearAfterRead instead to clear after reading (mcp-tools.js style)."
				},
				clearAfterRead: {
					type: "boolean",
					description: "Buffer mode only: clear the buffered logs for this tab AFTER reading, to avoid duplicate messages on subsequent calls (default: false). This matches mcp-tools.js behavior."
				},
				pattern: {
					type: "string",
					description: "Optional regex filter applied to message/exception text. Supports /pattern/flags syntax."
				},
				onlyErrors: {
					type: "boolean",
					description: "Only return error-level console messages (and exceptions when includeExceptions=true). Default: false."
				},
				limit: {
					type: "number",
					description: "Limit returned console messages. In snapshot mode this is an alias for maxMessages; in buffer mode it limits returned messages from the buffer."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.FILE_UPLOAD,
		description: "Upload files to web forms with file input elements using Chrome DevTools Protocol",
		inputSchema: {
			type: "object",
			properties: {
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)"
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab when tabId is omitted"
				},
				selector: {
					type: "string",
					description: "CSS selector for the file input element (input[type=\"file\"])"
				},
				filePath: {
					type: "string",
					description: "Local file path to upload"
				},
				fileUrl: {
					type: "string",
					description: "URL to download file from before uploading"
				},
				base64Data: {
					type: "string",
					description: "Base64 encoded file data to upload"
				},
				fileName: {
					type: "string",
					description: "Optional filename when using base64 or URL (default: \"uploaded-file\")"
				},
				multiple: {
					type: "boolean",
					description: "Whether the input accepts multiple files (default: false)"
				}
			},
			required: ["selector"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.HANDLE_DIALOG,
		description: "Handle JavaScript dialogs (alert/confirm/prompt) via CDP",
		inputSchema: {
			type: "object",
			properties: {
				action: {
					type: "string",
					description: "accept | dismiss"
				},
				promptText: {
					type: "string",
					description: "Optional prompt text when accepting a prompt"
				}
			},
			required: ["action"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.GIF_RECORDER,
		description: "Record browser tab activity as an animated GIF.\n\nModes:\n- Fixed FPS mode (action=\"start\"): Captures frames at regular intervals. Good for animations/videos.\n- Auto-capture mode (action=\"auto_start\"): Captures frames automatically when chrome_computer or chrome_navigate actions succeed. Better for interaction recordings with natural pacing.\n\nUse \"stop\" to end recording and save the GIF.",
		inputSchema: {
			type: "object",
			properties: {
				action: {
					type: "string",
					enum: [
						"start",
						"stop",
						"status",
						"auto_start",
						"capture",
						"clear",
						"export"
					],
					description: "Action to perform:\n- \"start\": Begin fixed-FPS recording (captures frames at regular intervals)\n- \"auto_start\": Begin auto-capture mode (frames captured on tool actions)\n- \"stop\": End recording and save GIF\n- \"status\": Get current recording state\n- \"capture\": Manually trigger a frame capture in auto mode\n- \"clear\": Clear all recording state and cached GIF without saving\n- \"export\": Export the last recorded GIF (download or drag&drop upload)"
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab). Used with \"start\"/\"auto_start\" for recording, and with \"export\" (download=false) for drag&drop upload target."
				},
				fps: {
					type: "number",
					description: "Frames per second for fixed-FPS mode (1-30, default: 5). Higher values = smoother but larger file."
				},
				durationMs: {
					type: "number",
					description: "Maximum recording duration in milliseconds (default: 5000, max: 60000). Only for fixed-FPS mode."
				},
				maxFrames: {
					type: "number",
					description: "Maximum number of frames to capture (default: 50 for fixed-FPS, 100 for auto mode, max: 300)."
				},
				width: {
					type: "number",
					description: "Output GIF width in pixels (default: 800, max: 1920)."
				},
				height: {
					type: "number",
					description: "Output GIF height in pixels (default: 600, max: 1080)."
				},
				maxColors: {
					type: "number",
					description: "Maximum colors in palette (default: 256). Lower values = smaller file size."
				},
				filename: {
					type: "string",
					description: "Output filename (without extension). Defaults to timestamped name."
				},
				captureDelayMs: {
					type: "number",
					description: "Auto-capture mode only: Delay in ms after action before capturing frame (default: 150). Allows UI to stabilize."
				},
				frameDelayCs: {
					type: "number",
					description: "Auto-capture mode only: Display duration per frame in centiseconds (default: 20 = 200ms per frame)."
				},
				annotation: {
					type: "string",
					description: "Auto-capture mode only (action=\"capture\"): Optional text label to render on the captured frame."
				},
				download: {
					type: "boolean",
					description: "Export action only: Set to true (default) to download the GIF, or false to upload via drag&drop."
				},
				coordinates: {
					type: "object",
					description: "Export action only (when download=false): Target coordinates for drag&drop upload.",
					properties: {
						x: { type: "number" },
						y: { type: "number" }
					},
					required: ["x", "y"]
				},
				ref: {
					type: "string",
					description: "Export action only (when download=false): Element ref from chrome_read_page for drag&drop target."
				},
				selector: {
					type: "string",
					description: "Export action only (when download=false): CSS selector for drag&drop target element."
				},
				enhancedRendering: {
					type: "object",
					description: "Auto-capture mode only: Configure visual overlays for recorded actions (click indicators, drag paths, labels). Pass `true` to enable all defaults.",
					properties: {
						clickIndicators: {
							oneOf: [{ type: "boolean" }, {
								type: "object",
								properties: {
									enabled: {
										type: "boolean",
										description: "Enable click indicators (default: true)"
									},
									color: {
										type: "string",
										description: "CSS color for click indicator (default: \"rgba(255, 87, 34, 0.8)\")"
									},
									radius: {
										type: "number",
										description: "Initial radius in px (default: 20)"
									},
									animationDurationMs: {
										type: "number",
										description: "Animation duration in ms (default: 400)"
									},
									animationFrames: {
										type: "number",
										description: "Number of animation frames (default: 3)"
									},
									animationIntervalMs: {
										type: "number",
										description: "Interval between animation frames in ms (default: 80)"
									}
								}
							}],
							description: "Click indicator overlay config (true for defaults, or object for custom)."
						},
						dragPaths: {
							oneOf: [{ type: "boolean" }, {
								type: "object",
								properties: {
									enabled: {
										type: "boolean",
										description: "Enable drag path rendering (default: true)"
									},
									color: {
										type: "string",
										description: "CSS color for drag path (default: \"rgba(33, 150, 243, 0.7)\")"
									},
									lineWidth: {
										type: "number",
										description: "Line width in px (default: 3)"
									},
									lineDash: {
										type: "array",
										items: { type: "number" },
										description: "Dash pattern (default: [6, 4])"
									},
									arrowSize: {
										type: "number",
										description: "Arrow head size in px (default: 10)"
									}
								}
							}],
							description: "Drag path overlay config (true for defaults, or object for custom)."
						},
						labels: {
							oneOf: [{ type: "boolean" }, {
								type: "object",
								properties: {
									enabled: {
										type: "boolean",
										description: "Enable action labels (default: true)"
									},
									font: {
										type: "string",
										description: "Font for labels (default: \"bold 12px sans-serif\")"
									},
									textColor: {
										type: "string",
										description: "Text color (default: \"#fff\")"
									},
									bgColor: {
										type: "string",
										description: "Background color (default: \"rgba(0,0,0,0.7)\")"
									},
									padding: {
										type: "number",
										description: "Padding in px (default: 4)"
									},
									borderRadius: {
										type: "number",
										description: "Border radius in px (default: 4)"
									},
									offset: {
										type: "object",
										properties: {
											x: { type: "number" },
											y: { type: "number" }
										},
										description: "Offset from action position (default: {x: 10, y: -20})"
									}
								}
							}],
							description: "Action label overlay config (true for defaults, or object for custom)."
						},
						durationMs: {
							type: "number",
							description: "How long overlays remain visible in ms (default: 1500)."
						}
					}
				}
			},
			required: ["action"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.GET_PAGE_TEXT,
		description: "Extract the readable main article from a page using Readability. Returns clean text, article HTML, and metadata such as title, excerpt, author, site name, language, and length.",
		inputSchema: {
			type: "object",
			properties: {
				selector: {
					type: "string",
					description: "Optional CSS selector. When provided, returns text from that element instead of Readability article extraction."
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.GET_TAB_URL,
		description: "Get the current URL and title of a specified browser tab. Returns url, title, tabId, and favIconUrl. Simpler and faster than get_windows_and_tabs when you only need the current URL.",
		inputSchema: {
			type: "object",
			properties: {
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab in current window)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.GET_SCROLL_STATE,
		description: "Get the native state of the page or a scrollable container. Returns target, y, maxY, atTop, and atBottom. Fails explicitly when a requested scroll container cannot be found.",
		inputSchema: {
			type: "object",
			properties: {
				containerSelector: {
					type: "string",
					description: "CSS selector of the scroll container. Auto-detects the main container if omitted."
				},
				frameSelector: {
					type: "string",
					description: "Optional CSS selector for a same-origin iframe containing the scroll container."
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.SCROLL,
		description: "Scroll the page or a scrollable container. Supports multiple scroll modes:\n- Pixel scroll: specify amount (positive=down/right) and optional direction\n- Edge scroll: set toBottom=true or toTop=true; add lazyLoad=true to take one paced step so lazy content can render, then repeat until atBottom=true\n- Element scroll: set selector to scroll an element into view\nWhen containerSelector is omitted, auto-detects the main scrollable container by walking the DOM tree.",
		inputSchema: {
			type: "object",
			properties: {
				amount: {
					type: "number",
					description: "Pixels to scroll. Positive scrolls down/right, negative scrolls up/left. When direction is set without amount, defaults to 300."
				},
				direction: {
					type: "string",
					enum: [
						"down",
						"up",
						"left",
						"right"
					],
					description: "Scroll direction. Used with amount or defaults to 300px."
				},
				toBottom: {
					type: "boolean",
					description: "Scroll to the very bottom of the scroll container."
				},
				lazyLoad: {
					type: "boolean",
					description: "With toBottom=true, take a short paced step and pause for lazy-loaded content. Repeat until the response has atBottom=true (default: false)."
				},
				lazyLoadStep: {
					type: "number",
					description: "Pixels per paced lazy-load step (default: 400; only used with toBottom=true and lazyLoad=true)."
				},
				lazyLoadWaitMs: {
					type: "number",
					description: "Milliseconds to wait after each paced lazy-load step (default: 800; only used with toBottom=true and lazyLoad=true)."
				},
				lazyLoadMaxSteps: {
					type: "number",
					description: "Maximum paced lazy-load steps per request (default: 1; capped to keep the request below 2 seconds)."
				},
				toTop: {
					type: "boolean",
					description: "Scroll to the very top of the scroll container."
				},
				selector: {
					type: "string",
					description: "CSS selector of an element to scroll into view. Uses scrollIntoView by default."
				},
				scrollIntoView: {
					type: "boolean",
					description: "When selector is given: use scrollIntoView (default: true). When false, sets the container scrollTop to the element's offsetTop."
				},
				block: {
					type: "string",
					enum: [
						"start",
						"center",
						"end",
						"nearest"
					],
					description: "scrollIntoView vertical alignment (default: \"center\" when scrolling element into view)."
				},
				behavior: {
					type: "string",
					enum: ["auto", "smooth"],
					description: "Scroll behavior (default: \"auto\" for instant). Use \"smooth\" for animated scroll."
				},
				containerSelector: {
					type: "string",
					description: "CSS selector of the scroll container. When omitted, auto-detects the main scrollable container by inspecting overflow styles on ancestor elements."
				},
				frameSelector: {
					type: "string",
					description: "Optional CSS selector for a same-origin iframe to scroll inside."
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.WAIT,
		description: "Wait for a DOM element or JavaScript condition to become true. Polls the page at a configurable interval until the condition is met or the timeout expires. Does NOT throw on timeout — returns { found: false } so the caller can decide how to proceed.",
		inputSchema: {
			type: "object",
			properties: {
				selector: {
					type: "string",
					description: "CSS selector of the element to wait for."
				},
				waitFor: {
					type: "string",
					enum: [
						"visible",
						"present",
						"hidden",
						"gone",
						"enabled"
					],
					description: "What to check:\n- \"visible\" (default): element exists AND is visible (offsetParent !== null)\n- \"present\": element exists in DOM\n- \"hidden\": element exists but is hidden\n- \"gone\": element does NOT exist in DOM\n- \"enabled\": element exists, is visible, and not disabled"
				},
				jsCondition: {
					type: "string",
					description: `Custom JavaScript expression that returns boolean. Evaluated in the page context. Alternative to selector+waitFor. Example: 'document.querySelectorAll(".item").length >= 10'`
				},
				frameSelector: {
					type: "string",
					description: "Optional CSS selector for a same-origin iframe in which to evaluate the condition."
				},
				timeout: {
					type: "number",
					description: "Maximum wait time in milliseconds (default: 10000, max: 120000)."
				},
				pollInterval: {
					type: "number",
					description: "Polling interval in milliseconds (default: 200, min: 50)."
				},
				stableForMs: {
					type: "number",
					description: "Require the condition to remain true continuously for this many milliseconds before returning (default: 0)."
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				}
			},
			required: []
		}
	},
	{
		name: TOOL_NAMES.BROWSER.EXTRACT,
		description: "Extract structured data from a web page using CSS selectors. Supports nested field extraction, same-origin iframe targeting, table extraction, and configurable limits.\n\nExample:\n{\n  \"selector\": \".product-card\",\n  \"fields\": [\n    { \"name\": \"title\", \"selector\": \".product-title\", \"type\": \"text\" },\n    { \"name\": \"price\", \"selector\": \".price\", \"type\": \"number\" },\n    { \"name\": \"link\", \"selector\": \"a\", \"type\": \"href\" }\n  ]\n}",
		inputSchema: {
			type: "object",
			properties: {
				selector: {
					type: "string",
					description: "CSS selector for elements to extract (each match becomes one item in the result array)."
				},
				fields: {
					type: "array",
					description: "Fields to extract from each matched element. Each field defines a name, a relative CSS selector, and how to extract the value.",
					items: {
						type: "object",
						properties: {
							name: {
								type: "string",
								description: "Field name in the output object (required)."
							},
							selector: {
								type: "string",
								description: "CSS selector relative to the parent element. If omitted, uses the parent element itself."
							},
							type: {
								type: "string",
								enum: [
									"text",
									"html",
									"outerHtml",
									"attribute",
									"number",
									"href",
									"src",
									"table"
								],
								description: "How to extract the value:\n- \"text\" (default): element.textContent (trimmed)\n- \"html\": element.innerHTML\n- \"outerHtml\": element.outerHTML\n- \"attribute\": element.getAttribute(attribute)\n- \"number\": parseFloat(textContent) or null\n- \"href\": anchor.href (resolved absolute URL)\n- \"src\": img/video/iframe src (resolved absolute URL)\n- \"table\": table headers and rows, including colspan/rowspan"
							},
							attribute: {
								type: "string",
								description: "Attribute name when type is \"attribute\" (e.g. \"href\", \"data-id\", \"alt\")."
							},
							multiple: {
								type: "boolean",
								description: "When true, returns an array of ALL matching sub-elements. When false (default), returns only the first match."
							},
							defaultValue: { description: "Fallback value when the selector produces no match (default: null)." }
						},
						required: ["name"]
					}
				},
				contextSelector: {
					type: "string",
					description: "Optional parent container that narrows the extraction scope. Equivalent to calling document.querySelector(contextSelector).querySelectorAll(selector)."
				},
				frameSelector: {
					type: "string",
					description: "Optional CSS selector for a same-origin iframe to extract from."
				},
				limit: {
					type: "number",
					description: "Maximum number of items to return (default: no limit)."
				},
				offset: {
					type: "number",
					description: "Skip the first N matched elements (default: 0)."
				},
				waitForSelector: {
					type: "boolean",
					description: "When true, waits for the selector to appear in the DOM before extracting (default: true)."
				},
				waitTimeout: {
					type: "number",
					description: "Maximum time in ms to wait for the selector to appear when waitForSelector is true (default: 5000)."
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				}
			},
			required: ["selector", "fields"]
		}
	},
	{
		name: TOOL_NAMES.BROWSER.CLICK_AND_WAIT,
		description: "Click a CSS-selected element, then wait for another selector to reach the requested state.",
		inputSchema: {
			type: "object",
			properties: {
				selector: {
					type: "string",
					description: "CSS selector of the element to click."
				},
				waitSelector: {
					type: "string",
					description: "CSS selector to wait for after clicking."
				},
				waitFor: {
					type: "string",
					enum: [
						"visible",
						"present",
						"hidden",
						"gone",
						"enabled"
					],
					description: "Expected state for waitSelector (default: visible)."
				},
				waitTimeout: {
					type: "number",
					description: "Maximum wait time in milliseconds (default: 10000)."
				},
				tabId: {
					type: "number",
					description: "Target tab ID (default: active tab)."
				},
				windowId: {
					type: "number",
					description: "Target window ID to pick active tab from (when tabId is omitted)."
				},
				frameId: {
					type: "number",
					description: "Target frame ID for the click."
				},
				frameSelector: {
					type: "string",
					description: "Optional same-origin iframe selector in which to wait."
				}
			},
			required: ["selector", "waitSelector"]
		}
	}
];
for (const tool of TOOL_SCHEMAS) if ([
	TOOL_NAMES.BROWSER.NAVIGATE,
	TOOL_NAMES.BROWSER.CLICK,
	TOOL_NAMES.BROWSER.FILL,
	TOOL_NAMES.BROWSER.SCROLL,
	TOOL_NAMES.BROWSER.CLICK_AND_WAIT
].includes(tool.name)) tool.inputSchema.properties.expectedUrl = {
	type: "string",
	description: "Refuse this write unless the target tab URL starts with this value."
};
var EDGE_LABELS = {
	DEFAULT: "default",
	TRUE: "true",
	FALSE: "false",
	ON_ERROR: "onError"
};
var RR_STEP_TYPES = {
	CLICK: "click",
	DBLCLICK: "dblclick",
	FILL: "fill",
	DRAG: "drag",
	KEY: "key",
	WAIT: "wait",
	ASSERT: "assert",
	IF: "if",
	FOREACH: "foreach",
	WHILE: "while",
	NAVIGATE: "navigate",
	SCRIPT: "script",
	HTTP: "http",
	EXTRACT: "extract",
	SCREENSHOT: "screenshot",
	SCROLL: "scroll",
	TRIGGER_EVENT: "triggerEvent",
	SET_ATTRIBUTE: "setAttribute",
	LOOP_ELEMENTS: "loopElements",
	SWITCH_FRAME: "switchFrame",
	OPEN_TAB: "openTab",
	SWITCH_TAB: "switchTab",
	CLOSE_TAB: "closeTab",
	EXECUTE_FLOW: "executeFlow",
	HANDLE_DOWNLOAD: "handleDownload",
	DELAY: "delay"
};
function ensureTarget(t) {
	return t && typeof t === "object" ? t : { candidates: [] };
}
function topoOrder(nodes, edges) {
	const id2n = new Map(nodes.map((n) => [n.id, n]));
	const indeg = new Map(nodes.map((n) => [n.id, 0]));
	for (const e of edges) indeg.set(e.to, (indeg.get(e.to) || 0) + 1);
	const nexts = new Map(nodes.map((n) => [n.id, []]));
	for (const e of edges) nexts.get(e.from).push(e.to);
	const q = nodes.filter((n) => (indeg.get(n.id) || 0) === 0).map((n) => n.id);
	const out = [];
	while (q.length) {
		const id = q.shift();
		const n = id2n.get(id);
		if (!n) continue;
		out.push(n);
		for (const v of nexts.get(id)) {
			indeg.set(v, (indeg.get(v) || 0) - 1);
			if ((indeg.get(v) || 0) === 0) q.push(v);
		}
	}
	return out.length === nodes.length ? out : nodes.slice();
}
function mapStepToNodeConfig(step) {
	if (!step || typeof step !== "object") return {};
	const src = step;
	const out = {};
	for (const [k, v] of Object.entries(src)) {
		if (k === "id" || k === "type") continue;
		out[k] = v;
	}
	const target = out["target"];
	if (target) out["target"] = ensureTarget(target);
	const start = out["start"];
	if (start) out["start"] = ensureTarget(start);
	const end = out["end"];
	if (end) out["end"] = ensureTarget(end);
	return out;
}
function stepsToNodes(steps) {
	const arr = [];
	steps.forEach((step, i) => {
		const obj = step && typeof step === "object" ? step : {};
		const idValue = obj["id"];
		const typeValue = obj["type"];
		const id = typeof idValue === "string" && idValue ? idValue : `n_${i}`;
		const type = typeof typeValue === "string" && typeValue ? typeValue : RR_STEP_TYPES.SCRIPT;
		arr.push({
			id,
			type,
			config: mapStepToNodeConfig(step)
		});
	});
	return arr;
}
var STEP_TYPES = {
	CLICK: "click",
	DBLCLICK: "dblclick",
	FILL: "fill",
	TRIGGER_EVENT: "triggerEvent",
	SET_ATTRIBUTE: "setAttribute",
	SCREENSHOT: "screenshot",
	SWITCH_FRAME: "switchFrame",
	LOOP_ELEMENTS: "loopElements",
	KEY: "key",
	SCROLL: "scroll",
	DRAG: "drag",
	WAIT: "wait",
	ASSERT: "assert",
	SCRIPT: "script",
	IF: "if",
	FOREACH: "foreach",
	WHILE: "while",
	NAVIGATE: "navigate",
	HTTP: "http",
	EXTRACT: "extract",
	OPEN_TAB: "openTab",
	SWITCH_TAB: "switchTab",
	CLOSE_TAB: "closeTab",
	HANDLE_DOWNLOAD: "handleDownload",
	EXECUTE_FLOW: "executeFlow",
	TRIGGER: "trigger",
	DELAY: "delay"
};
var REG = /* @__PURE__ */ new Map();
function registerNodeSpec(spec) {
	REG.set(spec.type, spec);
}
function getNodeSpec(type) {
	return REG.get(type);
}
function listNodeSpecs() {
	return Array.from(REG.values());
}
function registerBuiltinSpecs() {
	registerNodeSpec({
		type: STEP_TYPES.NAVIGATE,
		version: 1,
		display: {
			label: "导航",
			iconClass: "icon-navigate",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "url",
			label: "URL",
			type: "string",
			required: true,
			placeholder: "https://example.com",
			help: "目标地址，支持变量模板 {var}",
			default: ""
		}],
		defaults: { url: "" },
		validate: (cfg) => {
			const errs = [];
			if (!cfg || !cfg.url || String(cfg.url).trim() === "") errs.push("URL 必填");
			return errs;
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.CLICK,
		version: 1,
		display: {
			label: "点击",
			iconClass: "icon-click",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "target",
				label: "目标",
				type: "json",
				widget: "targetlocator",
				help: "选择或输入元素选择器"
			},
			{
				key: "before",
				label: "执行前",
				type: "object",
				fields: [{
					key: "scrollIntoView",
					label: "滚动到可见",
					type: "boolean",
					default: true
				}, {
					key: "waitForSelector",
					label: "等待选择器",
					type: "boolean",
					default: true
				}]
			},
			{
				key: "after",
				label: "执行后",
				type: "object",
				fields: [{
					key: "waitForNavigation",
					label: "等待导航完成",
					type: "boolean",
					default: false
				}, {
					key: "waitForNetworkIdle",
					label: "等待网络空闲",
					type: "boolean",
					default: false
				}]
			}
		],
		defaults: {
			before: {
				scrollIntoView: true,
				waitForSelector: true
			},
			after: {}
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.DBLCLICK,
		version: 1,
		display: {
			label: "双击",
			iconClass: "icon-click",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "target",
				label: "目标",
				type: "json",
				widget: "targetlocator"
			},
			{
				key: "before",
				label: "执行前",
				type: "object",
				fields: [{
					key: "scrollIntoView",
					label: "滚动到可见",
					type: "boolean",
					default: true
				}, {
					key: "waitForSelector",
					label: "等待选择器",
					type: "boolean",
					default: true
				}]
			},
			{
				key: "after",
				label: "执行后",
				type: "object",
				fields: [{
					key: "waitForNavigation",
					label: "等待导航完成",
					type: "boolean",
					default: false
				}, {
					key: "waitForNetworkIdle",
					label: "等待网络空闲",
					type: "boolean",
					default: false
				}]
			}
		],
		defaults: {
			before: {
				scrollIntoView: true,
				waitForSelector: true
			},
			after: {}
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.FILL,
		version: 1,
		display: {
			label: "填充",
			iconClass: "icon-fill",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "target",
			label: "目标",
			type: "json",
			widget: "targetlocator"
		}, {
			key: "value",
			label: "输入值",
			type: "string",
			required: true,
			help: "支持 {var} 模板"
		}],
		defaults: { value: "" }
	});
	registerNodeSpec({
		type: STEP_TYPES.KEY,
		version: 1,
		display: {
			label: "键盘",
			iconClass: "icon-key",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "keys",
			label: "按键序列",
			type: "string",
			widget: "keysequence",
			required: true,
			help: "如 Backspace Enter 或 cmd+a"
		}, {
			key: "target",
			label: "焦点目标(可选)",
			type: "json",
			widget: "targetlocator"
		}],
		defaults: { keys: "" }
	});
	registerNodeSpec({
		type: STEP_TYPES.SCROLL,
		version: 1,
		display: {
			label: "滚动",
			iconClass: "icon-scroll",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "mode",
				label: "模式",
				type: "select",
				options: [
					{
						label: "元素",
						value: "element"
					},
					{
						label: "偏移",
						value: "offset"
					},
					{
						label: "容器",
						value: "container"
					}
				],
				default: "offset"
			},
			{
				key: "target",
				label: "目标(当元素/容器)",
				type: "json",
				widget: "targetlocator"
			},
			{
				key: "offset",
				label: "偏移",
				type: "object",
				fields: [{
					key: "x",
					label: "X",
					type: "number"
				}, {
					key: "y",
					label: "Y",
					type: "number"
				}]
			}
		],
		defaults: {
			mode: "offset",
			offset: {
				x: 0,
				y: 300
			}
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.DRAG,
		version: 1,
		display: {
			label: "拖拽",
			iconClass: "icon-drag",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "start",
				label: "起点",
				type: "json",
				widget: "targetlocator"
			},
			{
				key: "end",
				label: "终点",
				type: "json",
				widget: "targetlocator"
			},
			{
				key: "path",
				label: "路径坐标",
				type: "array",
				item: {
					key: "p",
					label: "点",
					type: "object",
					fields: [{
						key: "x",
						label: "X",
						type: "number"
					}, {
						key: "y",
						label: "Y",
						type: "number"
					}]
				}
			}
		],
		defaults: {}
	});
	registerNodeSpec({
		type: STEP_TYPES.WAIT,
		version: 1,
		display: {
			label: "等待",
			iconClass: "icon-wait",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "condition",
			label: "条件(JSON)",
			type: "json",
			help: "如 {\"sleep\":1000} 或 {\"text\":\"Hello\",\"appear\":true}"
		}],
		defaults: { condition: { sleep: 500 } }
	});
	registerNodeSpec({
		type: STEP_TYPES.ASSERT,
		version: 1,
		display: {
			label: "断言",
			iconClass: "icon-assert",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }, { label: "onError" }]
		},
		schema: [{
			key: "assert",
			label: "断言(JSON)",
			type: "json",
			help: "如 {\"exists\":\"#id\"} / {\"visible\":\".btn\"}"
		}, {
			key: "failStrategy",
			label: "失败策略",
			type: "select",
			options: [
				{
					label: "停止",
					value: "stop"
				},
				{
					label: "警告",
					value: "warn"
				},
				{
					label: "重试",
					value: "retry"
				}
			],
			default: "stop"
		}],
		defaults: { assert: {} }
	});
	registerNodeSpec({
		type: STEP_TYPES.HTTP,
		version: 1,
		display: {
			label: "HTTP",
			iconClass: "icon-http",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "method",
				label: "方法",
				type: "select",
				options: [
					"GET",
					"POST",
					"PUT",
					"PATCH",
					"DELETE"
				].map((m) => ({
					label: m,
					value: m
				})),
				default: "GET"
			},
			{
				key: "url",
				label: "URL",
				type: "string",
				required: true
			},
			{
				key: "headers",
				label: "请求头(JSON)",
				type: "json"
			},
			{
				key: "body",
				label: "请求体(JSON)",
				type: "json"
			},
			{
				key: "formData",
				label: "表单(JSON)",
				type: "json"
			},
			{
				key: "saveAs",
				label: "保存为变量",
				type: "string"
			},
			{
				key: "assign",
				label: "映射(JSON)",
				type: "json"
			}
		],
		defaults: { method: "GET" }
	});
	registerNodeSpec({
		type: STEP_TYPES.EXTRACT,
		version: 1,
		display: {
			label: "提取",
			iconClass: "icon-extract",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "selector",
				label: "选择器",
				type: "string",
				widget: "selector"
			},
			{
				key: "attr",
				label: "属性",
				type: "select",
				options: [
					{
						label: "文本(text)",
						value: "text"
					},
					{
						label: "文本(textContent)",
						value: "textContent"
					},
					{
						label: "自定义属性名",
						value: "attr"
					}
				]
			},
			{
				key: "js",
				label: "自定义JS",
				type: "string",
				help: "在页面中执行并返回值"
			},
			{
				key: "saveAs",
				label: "保存变量",
				type: "string",
				required: true
			}
		],
		defaults: { saveAs: "" }
	});
	registerNodeSpec({
		type: STEP_TYPES.SCREENSHOT,
		version: 1,
		display: {
			label: "截图",
			iconClass: "icon-screenshot",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "selector",
				label: "目标选择器",
				type: "string"
			},
			{
				key: "fullPage",
				label: "整页截图",
				type: "boolean",
				default: false
			},
			{
				key: "saveAs",
				label: "保存变量",
				type: "string"
			}
		],
		defaults: { fullPage: false }
	});
	registerNodeSpec({
		type: STEP_TYPES.TRIGGER_EVENT,
		version: 1,
		display: {
			label: "触发事件",
			iconClass: "icon-trigger",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "target",
				label: "目标",
				type: "json",
				widget: "targetlocator"
			},
			{
				key: "event",
				label: "事件类型",
				type: "string",
				required: true
			},
			{
				key: "bubbles",
				label: "冒泡",
				type: "boolean",
				default: true
			},
			{
				key: "cancelable",
				label: "可取消",
				type: "boolean",
				default: false
			}
		],
		defaults: { event: "" }
	});
	registerNodeSpec({
		type: STEP_TYPES.SET_ATTRIBUTE,
		version: 1,
		display: {
			label: "设置属性",
			iconClass: "icon-attr",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "target",
				label: "目标",
				type: "json",
				widget: "targetlocator"
			},
			{
				key: "name",
				label: "属性名",
				type: "string",
				required: true
			},
			{
				key: "value",
				label: "属性值",
				type: "string"
			},
			{
				key: "remove",
				label: "移除属性",
				type: "boolean",
				default: false
			}
		],
		defaults: { remove: false }
	});
	registerNodeSpec({
		type: STEP_TYPES.LOOP_ELEMENTS,
		version: 1,
		display: {
			label: "循环元素",
			iconClass: "icon-loop",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "selector",
				label: "选择器",
				type: "string",
				required: true
			},
			{
				key: "saveAs",
				label: "列表变量名",
				type: "string",
				default: "elements"
			},
			{
				key: "itemVar",
				label: "项变量名",
				type: "string",
				default: "item"
			},
			{
				key: "subflowId",
				label: "子流程ID",
				type: "string",
				required: true
			}
		],
		defaults: {
			saveAs: "elements",
			itemVar: "item"
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.SWITCH_FRAME,
		version: 1,
		display: {
			label: "切换Frame",
			iconClass: "icon-frame",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "frame",
			label: "frame定位",
			type: "object",
			fields: [{
				key: "index",
				label: "索引",
				type: "number"
			}, {
				key: "urlContains",
				label: "URL包含",
				type: "string"
			}]
		}],
		defaults: {}
	});
	registerNodeSpec({
		type: STEP_TYPES.HANDLE_DOWNLOAD,
		version: 1,
		display: {
			label: "下载处理",
			iconClass: "icon-download",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "filenameContains",
				label: "文件名包含",
				type: "string"
			},
			{
				key: "waitForComplete",
				label: "等待完成",
				type: "boolean",
				default: true
			},
			{
				key: "timeoutMs",
				label: "超时(ms)",
				type: "number",
				default: 6e4
			},
			{
				key: "saveAs",
				label: "保存变量",
				type: "string"
			}
		],
		defaults: {
			waitForComplete: true,
			timeoutMs: 6e4
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.SCRIPT,
		version: 1,
		display: {
			label: "脚本",
			iconClass: "icon-script",
			category: "Tools"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "world",
				label: "执行上下文",
				type: "select",
				options: [{
					label: "ISOLATED",
					value: "ISOLATED"
				}, {
					label: "MAIN",
					value: "MAIN"
				}],
				default: "ISOLATED"
			},
			{
				key: "code",
				label: "脚本代码",
				type: "string",
				widget: "code",
				required: true
			},
			{
				key: "when",
				label: "执行时机",
				type: "select",
				options: [{
					label: "before",
					value: "before"
				}, {
					label: "after",
					value: "after"
				}],
				default: "after"
			},
			{
				key: "assign",
				label: "映射(JSON)",
				type: "json"
			},
			{
				key: "saveAs",
				label: "保存变量",
				type: "string"
			}
		],
		defaults: {
			world: "ISOLATED",
			when: "after"
		}
	});
	registerNodeSpec({
		type: STEP_TYPES.OPEN_TAB,
		version: 1,
		display: {
			label: "打开标签",
			iconClass: "icon-openTab",
			category: "Tabs"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "url",
			label: "URL",
			type: "string"
		}, {
			key: "newWindow",
			label: "新窗口",
			type: "boolean",
			default: false
		}],
		defaults: { newWindow: false }
	});
	registerNodeSpec({
		type: "executeFlow",
		version: 1,
		display: {
			label: "执行子流程",
			iconClass: "icon-exec",
			category: "Flow"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "flowId",
				label: "流程ID",
				type: "string",
				required: true
			},
			{
				key: "inline",
				label: "内联执行",
				type: "boolean",
				default: false
			},
			{
				key: "args",
				label: "参数(JSON)",
				type: "json"
			}
		],
		defaults: { inline: false }
	});
	registerNodeSpec({
		type: STEP_TYPES.SWITCH_TAB,
		version: 1,
		display: {
			label: "切换标签",
			iconClass: "icon-switchTab",
			category: "Tabs"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "tabId",
				label: "TabId",
				type: "number"
			},
			{
				key: "urlContains",
				label: "URL包含",
				type: "string"
			},
			{
				key: "titleContains",
				label: "标题包含",
				type: "string"
			}
		],
		defaults: {}
	});
	registerNodeSpec({
		type: STEP_TYPES.CLOSE_TAB,
		version: 1,
		display: {
			label: "关闭标签",
			iconClass: "icon-closeTab",
			category: "Tabs"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "tabIds",
			label: "TabIds",
			type: "array",
			item: {
				key: "id",
				label: "id",
				type: "number"
			}
		}, {
			key: "url",
			label: "URL",
			type: "string"
		}],
		defaults: {}
	});
	registerNodeSpec({
		type: STEP_TYPES.IF,
		version: 1,
		display: {
			label: "条件",
			iconClass: "icon-if",
			category: "Logic"
		},
		ports: {
			inputs: 1,
			outputs: "any"
		},
		schema: [
			{
				key: "condition",
				label: "条件表达式(JSON)",
				type: "json",
				help: "如 {\"expression\":\"vars.a>0\"} 等"
			},
			{
				key: "branches",
				label: "分支",
				type: "array",
				item: {
					key: "b",
					label: "case",
					type: "object",
					fields: [
						{
							key: "id",
							label: "ID",
							type: "string"
						},
						{
							key: "name",
							label: "名称",
							type: "string"
						},
						{
							key: "expr",
							label: "表达式",
							type: "string"
						}
					]
				}
			},
			{
				key: "else",
				label: "启用 else",
				type: "boolean",
				default: true
			}
		],
		defaults: { else: true }
	});
	registerNodeSpec({
		type: STEP_TYPES.FOREACH,
		version: 1,
		display: {
			label: "循环",
			iconClass: "icon-foreach",
			category: "Logic"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "listVar",
				label: "列表变量",
				type: "string",
				required: true
			},
			{
				key: "itemVar",
				label: "项变量",
				type: "string",
				default: "item"
			},
			{
				key: "subflowId",
				label: "子流程ID",
				type: "string",
				required: true
			},
			{
				key: "concurrency",
				label: "并发数",
				type: "number",
				default: 1,
				help: "并发执行子流程（浅拷贝变量，不自动合并）"
			}
		],
		defaults: { itemVar: "item" }
	});
	registerNodeSpec({
		type: STEP_TYPES.WHILE,
		version: 1,
		display: {
			label: "循环",
			iconClass: "icon-while",
			category: "Logic"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "condition",
				label: "条件(JSON)",
				type: "json"
			},
			{
				key: "subflowId",
				label: "子流程ID",
				type: "string",
				required: true
			},
			{
				key: "maxIterations",
				label: "最大次数",
				type: "number",
				default: 100
			}
		],
		defaults: { maxIterations: 100 }
	});
	registerNodeSpec({
		type: STEP_TYPES.DELAY,
		version: 1,
		display: {
			label: "延迟",
			iconClass: "icon-delay",
			category: "Actions"
		},
		ports: {
			inputs: 1,
			outputs: [{ label: "default" }]
		},
		schema: [{
			key: "sleep",
			label: "延迟",
			type: "number",
			widget: "duration",
			required: true,
			default: 1e3
		}],
		defaults: { sleep: 1e3 }
	});
	registerNodeSpec({
		type: STEP_TYPES.TRIGGER,
		version: 1,
		display: {
			label: "触发器",
			iconClass: "icon-trigger",
			category: "Flow"
		},
		ports: {
			inputs: 0,
			outputs: [{ label: "default" }]
		},
		schema: [
			{
				key: "enabled",
				label: "启用",
				type: "boolean",
				default: true
			},
			{
				key: "description",
				label: "描述",
				type: "string"
			},
			{
				key: "modes",
				label: "模式",
				type: "object",
				fields: [
					{
						key: "manual",
						label: "手动",
						type: "boolean",
						default: true
					},
					{
						key: "url",
						label: "URL 触发",
						type: "boolean",
						default: false
					},
					{
						key: "contextMenu",
						label: "右键菜单",
						type: "boolean",
						default: false
					},
					{
						key: "command",
						label: "快捷键",
						type: "boolean",
						default: false
					},
					{
						key: "dom",
						label: "DOM 事件",
						type: "boolean",
						default: false
					},
					{
						key: "schedule",
						label: "定时",
						type: "boolean",
						default: false
					}
				]
			},
			{
				key: "url",
				label: "URL 规则",
				type: "object",
				fields: [{
					key: "rules",
					label: "规则列表",
					type: "array",
					item: {
						key: "rule",
						label: "规则",
						type: "object",
						fields: [{
							key: "kind",
							label: "类型",
							type: "select",
							options: [
								{
									label: "URL",
									value: "url"
								},
								{
									label: "域名",
									value: "domain"
								},
								{
									label: "路径",
									value: "path"
								}
							],
							default: "url"
						}, {
							key: "value",
							label: "值",
							type: "string"
						}]
					}
				}]
			},
			{
				key: "contextMenu",
				label: "右键菜单",
				type: "object",
				fields: [{
					key: "title",
					label: "标题",
					type: "string",
					default: "运行工作流"
				}, {
					key: "enabled",
					label: "启用",
					type: "boolean",
					default: false
				}]
			},
			{
				key: "command",
				label: "快捷键",
				type: "object",
				fields: [{
					key: "commandKey",
					label: "快捷键",
					type: "string"
				}, {
					key: "enabled",
					label: "启用",
					type: "boolean",
					default: false
				}]
			},
			{
				key: "dom",
				label: "DOM 事件",
				type: "object",
				fields: [
					{
						key: "selector",
						label: "选择器",
						type: "string"
					},
					{
						key: "appear",
						label: "出现",
						type: "boolean",
						default: true
					},
					{
						key: "once",
						label: "一次",
						type: "boolean",
						default: true
					},
					{
						key: "debounceMs",
						label: "防抖(ms)",
						type: "number",
						default: 800
					},
					{
						key: "enabled",
						label: "启用",
						type: "boolean",
						default: false
					}
				]
			},
			{
				key: "schedules",
				label: "定时",
				type: "array",
				item: {
					key: "sched",
					label: "计划",
					type: "object",
					fields: [
						{
							key: "id",
							label: "ID",
							type: "string"
						},
						{
							key: "type",
							label: "类型",
							type: "select",
							options: [
								{
									label: "一次",
									value: "once"
								},
								{
									label: "间隔",
									value: "interval"
								},
								{
									label: "每日",
									value: "daily"
								}
							]
						},
						{
							key: "when",
							label: "时间(ISO/cron)",
							type: "string"
						},
						{
							key: "enabled",
							label: "启用",
							type: "boolean",
							default: true
						}
					]
				}
			}
		],
		defaults: { enabled: true }
	});
}
//#endregion
export { TOOL_SCHEMAS as a, registerBuiltinSpecs as c, TOOL_NAMES as i, stepsToNodes as l, NativeMessageType as n, getNodeSpec as o, STEP_TYPES as r, listNodeSpecs as s, EDGE_LABELS as t, topoOrder as u };
